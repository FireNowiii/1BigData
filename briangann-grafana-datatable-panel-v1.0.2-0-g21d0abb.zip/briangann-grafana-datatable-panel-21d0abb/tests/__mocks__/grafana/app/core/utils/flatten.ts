
export class flatten {
}
